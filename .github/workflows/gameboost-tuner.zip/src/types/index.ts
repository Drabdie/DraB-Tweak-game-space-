export type TweakMode = 'NON_ROOT' | 'SHIZUKU' | 'ROOT';

export type ProfileLevel = 'BALANCED' | 'PERFORMANCE' | 'EXTREME' | 'CUSTOM';

export type TweakCategory = 'SYSTEM_API' | 'WINDOW_DISPLAY' | 'PROCESS_MEMORY' | 'CPU_GPU' | 'KERNEL_VM' | 'NETWORK';

export interface TweakItem {
  id: string;
  name: string;
  category: TweakCategory;
  requiredMode: TweakMode;
  description: string;
  commandExplanation: string;
  shellCommand?: string;
  verificationCommand?: string;
  defaultValue: string;
  currentValue: string;
  recommendedValue: string;
  enabled: boolean;
  backedUpValue?: string;
  isDangerous: boolean;
  requiresReboot?: boolean;
}

export interface GameItem {
  packageName: string;
  appName: string;
  category: string;
  icon: string;
  fpsTarget: 60 | 90 | 120 | 144;
  profile: ProfileLevel;
  autoBoostEnabled: boolean;
  resolutionScale: number; // 0.8 to 1.0
  gameModeApi: 'PERFORMANCE' | 'STANDARD' | 'BATTERY';
  lastPlayed?: string;
}

export interface DeviceTelemetry {
  cpuCores: {
    coreId: number;
    cluster: 'LITTLE' | 'MID' | 'PRIME';
    curFreqMhz: number;
    maxFreqMhz: number;
    minFreqMhz: number;
    governor: string;
    usagePercent: number;
  }[];
  totalCpuUsagePercent: number;
  ram: {
    totalMb: number;
    usedMb: number;
    freeMb: number;
    zramMb: number;
  };
  thermal: {
    batteryTempC: number;
    cpuTempC: number;
    thermalHeadroom: number; // 0.0 (cool) to 1.0 (throttling threshold)
    thermalStatus: 'NONE' | 'LIGHT' | 'MODERATE' | 'SEVERE' | 'CRITICAL' | 'EMERGENCY';
    isWatchdogActive: boolean;
  };
  display: {
    refreshRateHz: number;
    currentFps: number;
    frameDropRate: number;
  };
}

export interface TweakBackupEntry {
  id: string;
  tweakId: string;
  targetPathOrSetting: string;
  originalValue: string;
  appliedValue: string;
  appliedTimestamp: number;
  mode: TweakMode;
  verified: boolean;
}

export interface AuditLogEntry {
  id: string;
  timestamp: number;
  mode: TweakMode;
  command: string;
  exitCode: number;
  output: string;
  status: 'SUCCESS' | 'FAILED' | 'ROLLED_BACK';
}

export interface OverlayConfig {
  enabled: boolean;
  showFps: boolean;
  showCpu: boolean;
  showRam: boolean;
  showTemp: boolean;
  opacity: number;
  size: 'COMPACT' | 'MEDIUM' | 'EXPANDED';
  position: { x: number; y: number };
}
