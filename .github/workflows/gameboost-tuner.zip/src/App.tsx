import React, { useState, useEffect } from 'react';
import {
  TweakMode,
  DeviceTelemetry,
  TweakItem,
  GameItem,
  TweakBackupEntry,
  AuditLogEntry,
  ProfileLevel,
  OverlayConfig,
} from './types';
import {
  INITIAL_TWEAKS,
  INITIAL_GAMES,
  INITIAL_TELEMETRY,
} from './data/mockSystem';
import { Navbar } from './components/Navbar';
import { DashboardTab } from './components/DashboardTab';
import { GamesTab } from './components/GamesTab';
import { TweaksTab } from './components/TweaksTab';
import { SafetyBackupsTab } from './components/SafetyBackupsTab';
import { ShizukuGuideTab } from './components/ShizukuGuideTab';
import { CodeExplorerTab } from './components/CodeExplorerTab';
import { AboutTab } from './components/AboutTab';
import { OverlayHUD } from './components/OverlayHUD';
import { ApkModal } from './components/ApkModal';
import { generateProjectZip, triggerFileDownload } from './utils/apkGenerator';

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [mode, setMode] = useState<TweakMode>('NON_ROOT');
  const [telemetry, setTelemetry] = useState<DeviceTelemetry>(INITIAL_TELEMETRY);
  const [tweaks, setTweaks] = useState<TweakItem[]>(INITIAL_TWEAKS);
  const [games, setGames] = useState<GameItem[]>(INITIAL_GAMES);
  const [activeProfile, setActiveProfile] = useState<ProfileLevel>('PERFORMANCE');

  // Room DB backups simulation
  const [backups, setBackups] = useState<TweakBackupEntry[]>([
    {
      id: 'b1',
      tweakId: 'window_animation_scale',
      targetPathOrSetting: 'settings.global.window_animation_scale',
      originalValue: '1.0',
      appliedValue: '0.0',
      appliedTimestamp: Date.now() - 3600000,
      mode: 'SHIZUKU',
      verified: true,
    },
    {
      id: 'b2',
      tweakId: 'cpu_scaling_governor',
      targetPathOrSetting: '/sys/devices/system/cpu/cpufreq/policy0/scaling_governor',
      originalValue: 'schedutil',
      appliedValue: 'performance',
      appliedTimestamp: Date.now() - 1800000,
      mode: 'ROOT',
      verified: true,
    },
    {
      id: 'b3',
      tweakId: 'vm_swappiness',
      targetPathOrSetting: '/proc/sys/vm/swappiness',
      originalValue: '60',
      appliedValue: '10',
      appliedTimestamp: Date.now() - 900000,
      mode: 'ROOT',
      verified: true,
    },
  ]);

  // Audit Logs
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([
    {
      id: 'log-1',
      timestamp: Date.now() - 3600000,
      mode: 'SHIZUKU',
      command: 'settings put global window_animation_scale 0.0',
      exitCode: 0,
      output: 'verified: 0.0',
      status: 'SUCCESS',
    },
    {
      id: 'log-2',
      timestamp: Date.now() - 1800000,
      mode: 'ROOT',
      command: 'echo performance > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor',
      exitCode: 0,
      output: 'policy0 scaling governor set to performance',
      status: 'SUCCESS',
    },
    {
      id: 'log-3',
      timestamp: Date.now() - 900000,
      mode: 'ROOT',
      command: 'echo 10 > /proc/sys/vm/swappiness',
      exitCode: 0,
      output: 'swappiness set to 10',
      status: 'SUCCESS',
    },
  ]);

  // Overlay HUD
  const [overlayActive, setOverlayActive] = useState<boolean>(true);
  const [overlayConfig, setOverlayConfig] = useState<OverlayConfig>({
    enabled: true,
    showFps: true,
    showCpu: true,
    showRam: true,
    showTemp: true,
    opacity: 0.95,
    size: 'MEDIUM',
    position: { x: window.innerWidth > 800 ? window.innerWidth - 290 : 20, y: 80 },
  });

  // Modals & Progress
  const [apkModalOpen, setApkModalOpen] = useState(false);
  const [isExportingZip, setIsExportingZip] = useState(false);
  const [isBoosting, setIsBoosting] = useState(false);

  // Live telemetry ticker: updates CPU frequencies and Choreographer FPS realistically
  useEffect(() => {
    const interval = setInterval(() => {
      setTelemetry((prev) => {
        // Slight fluctuation
        const jitter = (Math.random() - 0.5) * 4;
        const currentFps = Math.min(120, Math.max(116, Math.round(119.4 + jitter)));

        const updatedCores = prev.cpuCores.map((core) => {
          const coreUsageJitter = Math.floor((Math.random() - 0.5) * 8);
          const newUsage = Math.min(100, Math.max(20, core.usagePercent + coreUsageJitter));
          return {
            ...core,
            usagePercent: newUsage,
          };
        });

        const avgCpu = Math.round(
          updatedCores.reduce((acc, c) => acc + c.usagePercent, 0) / updatedCores.length
        );

        return {
          ...prev,
          totalCpuUsagePercent: avgCpu,
          cpuCores: updatedCores,
          display: {
            ...prev.display,
            currentFps,
          },
        };
      });
    }, 1500);

    return () => clearInterval(interval);
  }, []);

  // Quick Boost Action
  const handleTriggerBoost = () => {
    setIsBoosting(true);

    setTimeout(() => {
      // Free RAM & optimize telemetry
      setTelemetry((prev) => ({
        ...prev,
        ram: {
          ...prev.ram,
          usedMb: Math.max(3000, prev.ram.usedMb - 1200),
          freeMb: prev.ram.freeMb + 1200,
        },
        display: {
          ...prev.display,
          currentFps: 120,
          frameDropRate: 0.1,
        },
      }));

      // Add audit log
      const newLog: AuditLogEntry = {
        id: `log-${Date.now()}`,
        timestamp: Date.now(),
        mode,
        command:
          mode === 'NON_ROOT'
            ? 'PerformanceHintManager.reportActualDuration() + System.gc()'
            : mode === 'SHIZUKU'
            ? 'am kill-all && pm trim-caches 2G'
            : 'echo 3 > /proc/sys/vm/drop_caches && am kill-all',
        exitCode: 0,
        output: 'System cache trimmed, 1.2 GB RAM reclaimed, ADPF frame pacing active.',
        status: 'SUCCESS',
      };
      setAuditLogs((prev) => [newLog, ...prev]);
      setIsBoosting(false);
    }, 800);
  };

  // Toggle individual tweak
  const handleToggleTweak = (tweakId: string) => {
    setTweaks((prev) =>
      prev.map((t) => {
        if (t.id !== tweakId) return t;
        const willEnable = !t.enabled;

        if (willEnable) {
          // Backup original
          const backupEntry: TweakBackupEntry = {
            id: `backup-${Date.now()}`,
            tweakId: t.id,
            targetPathOrSetting: t.id,
            originalValue: t.currentValue || t.defaultValue,
            appliedValue: t.recommendedValue,
            appliedTimestamp: Date.now(),
            mode: t.requiredMode,
            verified: true,
          };
          setBackups((bList) => [backupEntry, ...bList.filter((b) => b.tweakId !== t.id)]);

          // Log
          const log: AuditLogEntry = {
            id: `log-${Date.now()}`,
            timestamp: Date.now(),
            mode: t.requiredMode,
            command: t.shellCommand || t.commandExplanation,
            exitCode: 0,
            output: `Verified: ${t.recommendedValue}`,
            status: 'SUCCESS',
          };
          setAuditLogs((lList) => [log, ...lList]);

          return {
            ...t,
            enabled: true,
            currentValue: t.recommendedValue,
            backedUpValue: t.defaultValue,
          };
        } else {
          // Restore
          const existingBackup = backups.find((b) => b.tweakId === t.id);
          const originalVal = existingBackup ? existingBackup.originalValue : t.defaultValue;
          setBackups((bList) => bList.filter((b) => b.tweakId !== t.id));

          const log: AuditLogEntry = {
            id: `log-${Date.now()}`,
            timestamp: Date.now(),
            mode: t.requiredMode,
            command: `restore ${t.id} -> ${originalVal}`,
            exitCode: 0,
            output: `Reverted to ${originalVal}`,
            status: 'ROLLED_BACK',
          };
          setAuditLogs((lList) => [log, ...lList]);

          return {
            ...t,
            enabled: false,
            currentValue: originalVal,
            backedUpValue: undefined,
          };
        }
      })
    );
  };

  // Restore individual tweak
  const handleRestoreTweak = (tweakId: string) => {
    handleToggleTweak(tweakId);
  };

  // Emergency Restore All
  const handleEmergencyRestoreAll = () => {
    // Revert all tweaks
    setTweaks((prev) =>
      prev.map((t) => ({
        ...t,
        enabled: false,
        currentValue: t.defaultValue,
        backedUpValue: undefined,
      }))
    );

    // Reset CPU governor in telemetry
    setTelemetry((prev) => ({
      ...prev,
      cpuCores: prev.cpuCores.map((c) => ({
        ...c,
        governor: 'schedutil',
        curFreqMhz: c.minFreqMhz + 400,
      })),
      thermal: {
        ...prev.thermal,
        thermalHeadroom: 0.85,
        batteryTempC: 34.0,
        cpuTempC: 38.0,
      },
    }));

    // Log action
    const log: AuditLogEntry = {
      id: `emergency-log-${Date.now()}`,
      timestamp: Date.now(),
      mode: 'ROOT',
      command: 'EmergencyRestoreAll(): Reverted all Room DB snapshots',
      exitCode: 0,
      output: `Successfully rolled back ${backups.length} snapshots. CPU governors returned to schedutil.`,
      status: 'ROLLED_BACK',
    };
    setAuditLogs((prev) => [log, ...prev]);

    // Clear backups
    setBackups([]);
  };

  // Simulate Overheat Trigger
  const handleSimulateOverheat = () => {
    // Set critical thermal headroom
    setTelemetry((prev) => ({
      ...prev,
      thermal: {
        ...prev.thermal,
        thermalHeadroom: 0.18, // < 0.30 critical throttle
        batteryTempC: 47.5,
        cpuTempC: 62.0,
        thermalStatus: 'CRITICAL',
      },
    }));

    // Watchdog automatic rollback triggers after 1 second!
    setTimeout(() => {
      // Revert CPU tweaks
      setTweaks((prev) =>
        prev.map((t) => {
          if (t.requiredMode === 'ROOT') {
            return {
              ...t,
              enabled: false,
              currentValue: t.defaultValue,
              backedUpValue: undefined,
            };
          }
          return t;
        })
      );

      // Revert CPU governors in telemetry
      setTelemetry((prev) => ({
        ...prev,
        cpuCores: prev.cpuCores.map((c) => ({
          ...c,
          governor: 'schedutil',
        })),
        thermal: {
          ...prev.thermal,
          thermalHeadroom: 0.65,
          batteryTempC: 38.0,
          cpuTempC: 44.0,
          thermalStatus: 'MODERATE',
        },
      }));

      // Log watchdog trigger
      const log: AuditLogEntry = {
        id: `watchdog-log-${Date.now()}`,
        timestamp: Date.now(),
        mode: 'ROOT',
        command: 'ThermalWatchdogService: HEADROOM_CRITICAL (<0.30)',
        exitCode: 0,
        output: 'ALARM: Device overheat detected! Emergency rollback of CPU frequency floors and performance governor.',
        status: 'ROLLED_BACK',
      };
      setAuditLogs((prev) => [log, ...prev]);
    }, 1200);
  };

  // Simulate Game Launch
  const handleSimulateGameLaunch = (game: GameItem) => {
    setActiveProfile(game.profile);
    handleTriggerBoost();
  };

  // Full Project ZIP Download
  const handleDownloadProjectZip = async () => {
    setIsExportingZip(true);
    try {
      const blob = await generateProjectZip();
      triggerFileDownload(blob, 'GameBoostTuner-FullSource.zip');
    } catch (e) {
      console.error(e);
    } finally {
      setIsExportingZip(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950">
      {/* Top Navbar */}
      <Navbar
        currentTab={currentTab}
        onTabChange={setCurrentTab}
        mode={mode}
        onModeChange={setMode}
        telemetry={telemetry}
        overlayActive={overlayActive}
        onToggleOverlay={() => setOverlayActive(!overlayActive)}
        onOpenApkModal={() => setApkModalOpen(true)}
        onDownloadProjectZip={handleDownloadProjectZip}
        isExportingZip={isExportingZip}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {currentTab === 'dashboard' && (
          <DashboardTab
            telemetry={telemetry}
            mode={mode}
            onTriggerBoost={handleTriggerBoost}
            isBoosting={isBoosting}
            activeProfile={activeProfile}
            onProfileSelect={setActiveProfile}
            onNavigateToTab={setCurrentTab}
          />
        )}

        {currentTab === 'games' && (
          <GamesTab
            games={games}
            onUpdateGame={(updated) =>
              setGames((prev) =>
                prev.map((g) => (g.packageName === updated.packageName ? updated : g))
              )
            }
            onAddGame={(newGame) => setGames((prev) => [newGame, ...prev])}
            onSimulateLaunch={handleSimulateGameLaunch}
            mode={mode}
          />
        )}

        {currentTab === 'tweaks' && (
          <TweaksTab
            tweaks={tweaks}
            currentMode={mode}
            onToggleTweak={handleToggleTweak}
            onRestoreTweak={handleRestoreTweak}
            onSwitchMode={setMode}
          />
        )}

        {currentTab === 'safety' && (
          <SafetyBackupsTab
            backups={backups}
            auditLogs={auditLogs}
            telemetry={telemetry}
            onEmergencyRestoreAll={handleEmergencyRestoreAll}
            onSimulateOverheat={handleSimulateOverheat}
            onClearAuditLogs={() => setAuditLogs([])}
          />
        )}

        {currentTab === 'shizuku' && (
          <ShizukuGuideTab currentMode={mode} onSwitchMode={setMode} />
        )}

        {currentTab === 'code' && (
          <CodeExplorerTab
            onDownloadProjectZip={handleDownloadProjectZip}
            isExportingZip={isExportingZip}
          />
        )}

        {currentTab === 'about' && <AboutTab />}
      </main>

      {/* Floating HUD Overlay */}
      {overlayActive && (
        <OverlayHUD
          telemetry={telemetry}
          config={overlayConfig}
          onClose={() => setOverlayActive(false)}
          onQuickBoost={handleTriggerBoost}
        />
      )}

      {/* APK Download Modal */}
      <ApkModal
        isOpen={apkModalOpen}
        onClose={() => setApkModalOpen(false)}
        onDownloadProjectZip={handleDownloadProjectZip}
      />

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>GameBoost Tuner • Android Performance Engine (v1.0.0)</span>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setApkModalOpen(true)}
              className="hover:text-emerald-400 font-semibold"
            >
              Скачать APK
            </button>
            <button
              onClick={handleDownloadProjectZip}
              className="hover:text-indigo-400"
            >
              Исходники (.zip)
            </button>
            <button
              onClick={() => setCurrentTab('about')}
              className="hover:text-cyan-400"
            >
              Манифест безопасности
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
