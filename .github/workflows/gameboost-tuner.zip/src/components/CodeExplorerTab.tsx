import React, { useState } from 'react';
import { ANDROID_PROJECT_FILES, AndroidSourceFile } from '../data/projectFiles';
import {
  FileCode,
  FolderTree,
  Copy,
  CheckCircle2,
  Download,
  Terminal,
  ExternalLink,
  Code2,
} from 'lucide-react';
import { triggerFileDownload } from '../utils/apkGenerator';

interface CodeExplorerTabProps {
  onDownloadProjectZip: () => void;
  isExportingZip: boolean;
}

export const CodeExplorerTab: React.FC<CodeExplorerTabProps> = ({
  onDownloadProjectZip,
  isExportingZip,
}) => {
  const [selectedFile, setSelectedFile] = useState<AndroidSourceFile>(ANDROID_PROJECT_FILES[4]); // default to app/build.gradle.kts
  const [copied, setCopied] = useState(false);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadSingleFile = () => {
    const blob = new Blob([selectedFile.content], { type: 'text/plain' });
    triggerFileDownload(blob, selectedFile.name);
  };

  const lines = selectedFile.content.split('\n');

  return (
    <div className="space-y-6">
      {/* Top action header */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 shadow-xl">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2 font-['Chakra_Petch']">
            <FileCode className="w-6 h-6 text-indigo-400" />
            <span>ИСХОДНЫЙ КОД И КОНФИГУРАЦИЯ СБОРКИ</span>
          </h2>
          <p className="text-xs text-slate-300 mt-1">
            Все файлы Android Studio проекта оптимизированы под KSP 2.1, Configuration Cache, R8 Full Mode и быстрый CI.
          </p>
        </div>

        <button
          onClick={onDownloadProjectZip}
          disabled={isExportingZip}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-900/30 transition-all self-start sm:self-auto disabled:opacity-50"
        >
          <Download className="w-4 h-4" />
          <span>Скачать весь проект (.zip)</span>
        </button>
      </div>

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: File Tree */}
        <div className="lg:col-span-4 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-2">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs font-semibold text-slate-400 uppercase tracking-wider">
            <span className="flex items-center gap-1.5">
              <FolderTree className="w-4 h-4 text-cyan-400" /> Файлы проекта
            </span>
            <span className="font-mono text-[10px] text-slate-500">
              {ANDROID_PROJECT_FILES.length} файлов
            </span>
          </div>

          <div className="space-y-1 max-h-[580px] overflow-y-auto pr-1">
            {ANDROID_PROJECT_FILES.map((file) => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left px-3 py-2 rounded-xl text-xs font-mono transition-all flex items-start gap-2.5 ${
                    isSelected
                      ? 'bg-slate-800 text-cyan-300 border border-cyan-500/30 shadow-sm'
                      : 'text-slate-400 hover:bg-slate-800/50 hover:text-slate-200'
                  }`}
                >
                  <Code2
                    className={`w-4 h-4 flex-shrink-0 mt-0.5 ${
                      isSelected ? 'text-cyan-400' : 'text-slate-500'
                    }`}
                  />
                  <div className="truncate">
                    <span className="font-semibold block truncate">
                      {file.name}
                    </span>
                    <span className="text-[10px] text-slate-500 block truncate">
                      {file.path}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column: Code Viewer */}
        <div className="lg:col-span-8 bg-slate-950 border border-slate-800 rounded-2xl shadow-xl overflow-hidden flex flex-col">
          {/* File Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3 bg-slate-900 border-b border-slate-800">
            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                <span className="font-mono font-bold text-xs sm:text-sm text-white">
                  {selectedFile.path}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-cyan-400 font-mono">
                  {selectedFile.language}
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                {selectedFile.description}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopyCode}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-all"
                title="Копировать код файла"
              >
                {copied ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Скопировано</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Копировать</span>
                  </>
                )}
              </button>

              <button
                onClick={handleDownloadSingleFile}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-all"
                title="Скачать файл"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Скачать</span>
              </button>
            </div>
          </div>

          {/* Code Viewer Body */}
          <div className="overflow-x-auto max-h-[580px] overflow-y-auto p-4 font-mono text-xs text-slate-300 select-text leading-relaxed">
            <table className="w-full border-collapse">
              <tbody>
                {lines.map((line, idx) => (
                  <tr key={idx} className="hover:bg-slate-900/50">
                    <td className="text-slate-600 select-none pr-4 text-right align-top w-8 text-[11px]">
                      {idx + 1}
                    </td>
                    <td className="whitespace-pre text-slate-200">
                      {line}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
