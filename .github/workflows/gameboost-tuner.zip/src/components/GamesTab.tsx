import React, { useState } from 'react';
import { GameItem, ProfileLevel, TweakMode } from '../types';
import {
  Gamepad2,
  Play,
  Plus,
  Settings2,
  CheckCircle2,
  Zap,
  Sliders,
  Shield,
  Clock,
  Sparkles,
  Info,
} from 'lucide-react';

interface GamesTabProps {
  games: GameItem[];
  onUpdateGame: (updated: GameItem) => void;
  onAddGame: (game: GameItem) => void;
  onSimulateLaunch: (game: GameItem) => void;
  mode: TweakMode;
}

export const GamesTab: React.FC<GamesTabProps> = ({
  games,
  onUpdateGame,
  onAddGame,
  onSimulateLaunch,
  mode,
}) => {
  const [selectedGame, setSelectedGame] = useState<GameItem | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newPkgName, setNewPkgName] = useState('');
  const [newAppName, setNewAppName] = useState('');
  const [newCategory, setNewCategory] = useState('3D Action / Shooter');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const handleLaunch = (game: GameItem) => {
    onSimulateLaunch(game);
    setToastMessage(`GameBoost: Применён профиль [${game.profile}] для ${game.appName}`);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const handleCreateGame = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPkgName || !newAppName) return;

    const game: GameItem = {
      packageName: newPkgName.trim(),
      appName: newAppName.trim(),
      category: newCategory,
      icon: '🎮',
      fpsTarget: 60,
      profile: 'PERFORMANCE',
      autoBoostEnabled: true,
      resolutionScale: 1.0,
      gameModeApi: 'PERFORMANCE',
      lastPlayed: 'Только что добавлена',
    };

    onAddGame(game);
    setShowAddModal(false);
    setNewPkgName('');
    setNewAppName('');
  };

  const profileColors: Record<ProfileLevel, string> = {
    BALANCED: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    PERFORMANCE: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30',
    EXTREME: 'bg-rose-500/10 text-rose-400 border-rose-500/30',
    CUSTOM: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
  };

  return (
    <div className="space-y-6">
      {/* Toast Feedback */}
      {toastMessage && (
        <div className="p-3.5 rounded-xl bg-gradient-to-r from-emerald-950 to-slate-900 border border-emerald-500/40 text-emerald-300 text-sm flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <span className="font-medium">{toastMessage}</span>
          </div>
          <span className="text-xs text-slate-400 font-mono">Accessibility Event</span>
        </div>
      )}

      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-slate-900/80 border border-slate-800 rounded-2xl p-6">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2 font-['Chakra_Petch']">
            <Gamepad2 className="w-6 h-6 text-cyan-400" />
            <span>БИБЛИОТЕКА ИГР И ИГРОВЫЕ ПРОФИЛИ</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Автоматическое обнаружение игр через манифест <code className="text-cyan-400 font-mono text-xs">&lt;queries&gt;</code> и назначение персональных твиков.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center justify-center gap-2 px-4 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 text-cyan-400" />
          <span>Добавить игру</span>
        </button>
      </div>

      {/* Games List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {games.map((game) => (
          <div
            key={game.packageName}
            className="bg-slate-900/90 border border-slate-800 hover:border-cyan-500/40 rounded-2xl p-5 shadow-lg transition-all space-y-4 flex flex-col justify-between"
          >
            {/* Header info */}
            <div>
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-2xl shadow-inner">
                    {game.icon}
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-base leading-tight">
                      {game.appName}
                    </h3>
                    <p className="text-[11px] text-slate-400 font-mono truncate max-w-[180px]">
                      {game.packageName}
                    </p>
                  </div>
                </div>

                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded-full border font-bold ${profileColors[game.profile]}`}
                >
                  {game.profile}
                </span>
              </div>

              {/* Game Stats & Target FPS */}
              <div className="grid grid-cols-2 gap-2 mt-4 text-xs font-mono">
                <div className="bg-slate-950/60 p-2 rounded-lg border border-slate-800/80">
                  <span className="text-slate-500 block text-[10px]">FPS TARGET</span>
                  <span className="text-emerald-400 font-bold">{game.fpsTarget} FPS</span>
                </div>
                <div className="bg-slate-950/60 p-2 rounded-lg border border-slate-800/80">
                  <span className="text-slate-500 block text-[10px]">GAME MODE API</span>
                  <span className="text-cyan-400 font-bold">{game.gameModeApi}</span>
                </div>
              </div>
            </div>

            {/* Profile Selector & Actions */}
            <div className="space-y-3 pt-2 border-t border-slate-800/80">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Авто-буст при старте:</span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={game.autoBoostEnabled}
                    onChange={(e) =>
                      onUpdateGame({ ...game, autoBoostEnabled: e.target.checked })
                    }
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-cyan-500" />
                </label>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setSelectedGame(game)}
                  className="flex-1 py-2 px-3 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center justify-center gap-1.5 transition-all"
                >
                  <Settings2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Настроить</span>
                </button>

                <button
                  onClick={() => handleLaunch(game)}
                  className="flex-1 py-2 px-3 rounded-lg text-xs font-bold bg-gradient-to-r from-cyan-500 to-emerald-500 hover:from-cyan-400 hover:to-emerald-400 text-slate-950 flex items-center justify-center gap-1.5 shadow-md shadow-cyan-500/10 active:scale-95 transition-all"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Запуск с Boost</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Edit Game Profile Modal */}
      {selectedGame && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-lg bg-slate-950 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-5 animate-scale-in">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-3">
                <span className="text-3xl">{selectedGame.icon}</span>
                <div>
                  <h3 className="font-bold text-white text-lg">{selectedGame.appName}</h3>
                  <p className="text-xs text-slate-400 font-mono">{selectedGame.packageName}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedGame(null)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs">
              {/* Profile Level */}
              <div>
                <label className="block text-slate-300 font-semibold mb-1.5">
                  Уровень игрового профиля:
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {(['BALANCED', 'PERFORMANCE', 'EXTREME', 'CUSTOM'] as ProfileLevel[]).map((lvl) => (
                    <button
                      key={lvl}
                      type="button"
                      onClick={() =>
                        setSelectedGame({ ...selectedGame, profile: lvl })
                      }
                      className={`py-2 px-1 text-center font-bold rounded-lg border transition-all ${
                        selectedGame.profile === lvl
                          ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500 shadow-sm'
                          : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                    >
                      {lvl}
                    </button>
                  ))}
                </div>
              </div>

              {/* Target FPS */}
              <div>
                <label className="block text-slate-300 font-semibold mb-1.5">
                  Целевой FPS экрана:
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[60, 90, 120, 144].map((fps) => (
                    <button
                      key={fps}
                      type="button"
                      onClick={() =>
                        setSelectedGame({ ...selectedGame, fpsTarget: fps as any })
                      }
                      className={`py-2 px-1 text-center font-mono font-bold rounded-lg border transition-all ${
                        selectedGame.fpsTarget === fps
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500'
                          : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                    >
                      {fps} FPS
                    </button>
                  ))}
                </div>
              </div>

              {/* Game Mode API */}
              <div>
                <label className="block text-slate-300 font-semibold mb-1.5">
                  Game Mode API (Android 12+):
                </label>
                <select
                  value={selectedGame.gameModeApi}
                  onChange={(e) =>
                    setSelectedGame({
                      ...selectedGame,
                      gameModeApi: e.target.value as any,
                    })
                  }
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white font-mono"
                >
                  <option value="PERFORMANCE">GAME_MODE_PERFORMANCE (Высокий приоритет потоков)</option>
                  <option value="STANDARD">GAME_MODE_STANDARD (Стандартный)</option>
                  <option value="BATTERY">GAME_MODE_BATTERY (Экономия батареи)</option>
                </select>
              </div>

              {/* Mode Restrictions note */}
              {mode === 'NON_ROOT' && (
                <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 flex items-start gap-2 text-[11px]">
                  <Info className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
                  <span>
                    В режиме <strong>Non-Root</strong> будут применены: Game Mode API, ADPF Performance Hints, DND заглушка и очистка собственного кэша. Твики частот ядер требуют Root или Shizuku.
                  </span>
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setSelectedGame(null)}
                className="px-4 py-2 rounded-lg text-slate-400 hover:text-white text-xs"
              >
                Отмена
              </button>
              <button
                type="button"
                onClick={() => {
                  onUpdateGame(selectedGame);
                  setSelectedGame(null);
                }}
                className="px-5 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md"
              >
                Сохранить настройки
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Custom Game Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <form
            onSubmit={handleCreateGame}
            className="w-full max-w-md bg-slate-950 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-4"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-base">Добавить игру или приложение</h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Название игры / приложения:
                </label>
                <input
                  type="text"
                  required
                  placeholder="Например: Minecraft, Wuthering Waves"
                  value={newAppName}
                  onChange={(e) => setNewAppName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Имя пакета (Package Name):
                </label>
                <input
                  type="text"
                  required
                  placeholder="com.mojang.minecraftpe"
                  value={newPkgName}
                  onChange={(e) => setNewPkgName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Жанр:
                </label>
                <input
                  type="text"
                  placeholder="Action, Sandbox, MOBA"
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 rounded-lg text-slate-400 hover:text-white text-xs"
              >
                Отмена
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-md"
              >
                Добавить
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
