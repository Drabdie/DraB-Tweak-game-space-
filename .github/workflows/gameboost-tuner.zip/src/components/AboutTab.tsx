import React from 'react';
import {
  ShieldAlert,
  Cpu,
  Layers,
  Zap,
  CheckCircle2,
  FileCode,
  Flame,
  Award,
  Terminal,
} from 'lucide-react';

export const AboutTab: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Hero Charter Banner */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-indigo-950/40 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-xs font-mono text-cyan-300">
          <Award className="w-3.5 h-3.5 text-cyan-400" />
          <span>ЧЕСТНАЯ ИНЖЕНЕРИЯ ПРОИЗВОДИТЕЛЬНОСТИ</span>
        </div>

        <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-['Chakra_Petch']">
          О ПРИЛОЖЕНИИ «GAMEBOOST TUNER»
        </h2>
        <p className="text-sm text-slate-300 max-w-3xl leading-relaxed">
          В отличие от многочисленных «Magic Tuner / Game Turbo» из Google Play, которые имитируют ускорение бутафорскими анимациями и очисткой памяти, GameBoost Tuner основан на строгих системных принципах Android: честное разделение прав, официальный ADPF, KSP сборка и строгий откат при перегреве.
        </p>
      </div>

      {/* 3 Pillars Comparison */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Pillar 1 */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-white text-base">
            1. Non-Root (Официальный SDK)
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Использует <strong>GameModeManager API</strong> (Android 12+) и <strong>ADPF PerformanceHintManager</strong>. Сообщает системе приоритет отрисовщика кадра. Никаких опасных или фиктивных твиков.
          </p>
        </div>

        {/* Pillar 2 */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <Terminal className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-white text-base">
            2. Shizuku (ADB UID 2000)
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Позволяет менять глобальные флаги через <strong>settings put global</strong> (убирает анимационные лаги, отключает RAM Plus / Swap на UFS) и замораживает тяжёлый фон через <code className="text-cyan-400">am force-stop</code>.
          </p>
        </div>

        {/* Pillar 3 */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <Cpu className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-white text-base">
            3. Root (su / sysfs / proc)
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Прямой доступ к ядру Linux: регуляторы частоты <strong>scaling_governor (performance)</strong>, минимальные пороги частот, I/O планировщик и VM swappiness. Только со снапшотом в Room DB.
          </p>
        </div>
      </div>

      {/* Why Fast Build APK Section */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <h3 className="text-lg font-bold text-white flex items-center gap-2 font-['Chakra_Petch']">
          <Zap className="w-5 h-5 text-cyan-400" />
          <span>КАК ДОСТИГНУТА МАКСИМАЛЬНАЯ СКОРОСТЬ СБОРКИ APK</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-slate-300">
          <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-1.5">
            <span className="font-bold text-cyan-300 block">KSP 2.x вместо kapt:</span>
            <p className="text-slate-400">
              Генерация кода для Room и Hilt выполняется напрямую через Kotlin Symbol Processing без промежуточного создания Java Stubs, что сокращает время компиляции на 40–55%.
            </p>
          </div>

          <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-1.5">
            <span className="font-bold text-cyan-300 block">Configuration Cache & Parallel:</span>
            <p className="text-slate-400">
              Включены флаги <code className="text-cyan-400">org.gradle.configuration-cache=true</code> и <code className="text-cyan-400">org.gradle.parallel=true</code> с многопоточным сборщиком мусора ParallelGC.
            </p>
          </div>

          <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-1.5">
            <span className="font-bold text-cyan-300 block">R8 Full Mode & Baseline Profiles:</span>
            <p className="text-slate-400">
              Агрессивный tree-shaking удаляет неиспользуемые классы и ресурсы, уменьшая размер APK и ускоряя холодный старт на телефоне.
            </p>
          </div>

          <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-1.5">
            <span className="font-bold text-cyan-300 block">Zero-Bloat зависимости:</span>
            <p className="text-slate-400">
              Только необходимые системные библиотеки (Jetpack Compose, Room, DataStore, Shizuku). Никаких раздутых аналитических SDK и рекламных трекеров.
            </p>
          </div>
        </div>
      </div>

      {/* Safety & Thermal Guarantee */}
      <div className="bg-slate-900/90 border border-rose-500/30 rounded-2xl p-6 shadow-xl space-y-3">
        <div className="flex items-center gap-2 text-rose-400">
          <Flame className="w-5 h-5" />
          <h3 className="font-bold text-white text-base font-['Chakra_Petch']">
            МАНИФЕСТ ТЕРМИЧЕСКОЙ БЕЗОПАСНОСТИ
          </h3>
        </div>
        <p className="text-xs text-slate-300 leading-relaxed">
          GameBoost Tuner <strong>никогда</strong> не отключает системные thermal-движки насовсем и не вмешивается в критические аппаратные предохранители батареи. Фоновый сервис непрерывно проверяет метрику <code className="text-cyan-400 font-mono">PowerManager.getThermalHeadroom</code>. Если запас охлаждения опускается ниже 0.30, приложение мгновенно сбрасывает все повышенные частоты до безопасных заводских значений.
        </p>
      </div>
    </div>
  );
};
