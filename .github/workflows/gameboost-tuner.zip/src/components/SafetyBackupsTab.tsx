import React, { useState } from 'react';
import { TweakBackupEntry, AuditLogEntry, DeviceTelemetry } from '../types';
import {
  ShieldCheck,
  AlertTriangle,
  RotateCcw,
  Flame,
  FileText,
  Clock,
  CheckCircle2,
  Trash2,
  Download,
  Upload,
  Activity,
  Terminal,
} from 'lucide-react';

interface SafetyBackupsTabProps {
  backups: TweakBackupEntry[];
  auditLogs: AuditLogEntry[];
  telemetry: DeviceTelemetry;
  onEmergencyRestoreAll: () => void;
  onSimulateOverheat: () => void;
  onClearAuditLogs: () => void;
}

export const SafetyBackupsTab: React.FC<SafetyBackupsTabProps> = ({
  backups,
  auditLogs,
  telemetry,
  onEmergencyRestoreAll,
  onSimulateOverheat,
  onClearAuditLogs,
}) => {
  const [restoreSuccessMsg, setRestoreSuccessMsg] = useState<string | null>(null);

  const handleEmergencyClick = () => {
    onEmergencyRestoreAll();
    setRestoreSuccessMsg('Все резервные копии успешно восстановлены к заводским значениям!');
    setTimeout(() => setRestoreSuccessMsg(null), 4000);
  };

  const handleExportJson = () => {
    const data = JSON.stringify({ backups, auditLogs, exportedAt: new Date().toISOString() }, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `GameBoost-Backups-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Success Notification Banner */}
      {restoreSuccessMsg && (
        <div className="p-4 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-sm flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <span className="font-semibold">{restoreSuccessMsg}</span>
          </div>
          <span className="text-xs text-slate-400 font-mono">Room DB Rollback</span>
        </div>
      )}

      {/* Header and Emergency Action */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 flex flex-col md:flex-row md:items-center md:justify-between gap-6 shadow-xl">
        <div className="space-y-1">
          <h2 className="text-xl font-bold text-white flex items-center gap-2 font-['Chakra_Petch']">
            <ShieldCheck className="w-6 h-6 text-emerald-400" />
            <span>ЦЕНТР БЕЗОПАСНОСТИ, СНАПШОТОВ И АВТО-ОТКАТА</span>
          </h2>
          <p className="text-xs text-slate-300 max-w-xl leading-relaxed">
            Каждое изменение параметров системы сохраняется в локальной базе Room перед выполнением.
            При сбое или перегреве система гарантированно откатывается к заводским настройкам.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={handleExportJson}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all"
          >
            <Download className="w-4 h-4 text-cyan-400" />
            <span>Экспорт JSON</span>
          </button>

          <button
            onClick={handleEmergencyClick}
            disabled={backups.length === 0}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white shadow-lg shadow-rose-900/30 transition-all active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Экстренный откат всех настроек ({backups.length})</span>
          </button>
        </div>
      </div>

      {/* Thermal Watchdog Interactive Simulator Card */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-orange-950/20 border border-orange-500/30 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-orange-500/10 border border-orange-500/30 flex items-center justify-center text-orange-400">
              <Flame className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base font-['Chakra_Petch']">
                ИНТЕРАКТИВНЫЙ ТЕСТ: THERMAL WATCHDOG (ЗАЩИТА ОТ ПЕРЕГРЕВА)
              </h3>
              <p className="text-xs text-slate-400">
                Мониторинг PowerManager.getThermalHeadroom (Android 11+). Порог триггера: &lt; 0.30
              </p>
            </div>
          </div>

          <button
            onClick={onSimulateOverheat}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-orange-600 hover:bg-orange-500 text-white shadow-md shadow-orange-900/40 flex items-center gap-2 self-start sm:self-auto transition-all active:scale-95"
          >
            <AlertTriangle className="w-4 h-4" />
            <span>Симулировать перегрев (&lt; 0.30)</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono">
          <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800">
            <span className="text-slate-500 block text-[10px]">ТЕКУЩИЙ HEADROOM</span>
            <span className="text-base font-bold text-cyan-400">
              {(telemetry.thermal.thermalHeadroom * 100).toFixed(0)}% (
              {telemetry.thermal.thermalHeadroom.toFixed(2)})
            </span>
          </div>
          <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800">
            <span className="text-slate-500 block text-[10px]">ТЕМПЕРАТУРА БАТАРЕИ / CPU</span>
            <span className="text-base font-bold text-orange-400">
              {telemetry.thermal.batteryTempC.toFixed(1)}°C / {telemetry.thermal.cpuTempC.toFixed(1)}°C
            </span>
          </div>
          <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800">
            <span className="text-slate-500 block text-[10px]">СТАТУС WATCHDOG</span>
            <span className="text-base font-bold text-emerald-400 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              АКТИВЕН В ФОНЕ
            </span>
          </div>
        </div>

        <p className="text-xs text-slate-400 leading-relaxed">
          При нажатии кнопки симуляции headroom падает до 0.18 (критический троттлинг). Фоновый сторож немедленно отменит опасные твики процессора (CPU governor вернётся в <code className="text-cyan-400">schedutil</code>), снимет блокировку минимальных частот и запишет запись в аудит.
        </p>
      </div>

      {/* Active Room DB Backups Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-white text-base flex items-center gap-2 font-['Chakra_Petch']">
            <FileText className="w-5 h-5 text-cyan-400" />
            <span>АКТИВНЫЕ СНАПШОТЫ В ROOM DB ({backups.length})</span>
          </h3>
          <span className="text-xs text-slate-500 font-mono">
            Table: tweak_backups
          </span>
        </div>

        {backups.length === 0 ? (
          <div className="p-8 text-center text-slate-500 text-xs border border-dashed border-slate-800 rounded-xl">
            Все настройки находятся в заводском состоянии. Измените твики, чтобы создать снапшоты.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800 text-[11px]">
                <tr>
                  <th className="py-2.5 px-3">Твик / Параметр</th>
                  <th className="py-2.5 px-3">Заводское (Original)</th>
                  <th className="py-2.5 px-3">Применённое (Active)</th>
                  <th className="py-2.5 px-3">Режим</th>
                  <th className="py-2.5 px-3">Статус</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {backups.map((b) => (
                  <tr key={b.id} className="hover:bg-slate-800/40">
                    <td className="py-2.5 px-3 font-bold text-white">
                      {b.tweakId}
                    </td>
                    <td className="py-2.5 px-3 text-amber-400 font-bold">
                      {b.originalValue}
                    </td>
                    <td className="py-2.5 px-3 text-cyan-400 font-bold">
                      {b.appliedValue}
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">
                      {b.mode}
                    </td>
                    <td className="py-2.5 px-3 text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Verified</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Audit Log Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Terminal className="w-5 h-5 text-indigo-400" />
            <h3 className="font-bold text-white text-base font-['Chakra_Petch']">
              ЖУРНАЛ ВЫПОЛНЕНИЯ SHELL / API ({auditLogs.length})
            </h3>
          </div>
          <button
            onClick={onClearAuditLogs}
            className="text-xs text-slate-400 hover:text-rose-400 flex items-center gap-1 font-medium transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Очистить лог</span>
          </button>
        </div>

        <div className="overflow-x-auto max-h-72 overflow-y-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800 sticky top-0 text-[11px]">
              <tr>
                <th className="py-2 px-3">Время</th>
                <th className="py-2 px-3">Команда Shell / API</th>
                <th className="py-2 px-3">Exit</th>
                <th className="py-2 px-3">Результат</th>
                <th className="py-2 px-3">Статус</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {auditLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-800/40">
                  <td className="py-2 px-3 text-slate-500 whitespace-nowrap">
                    {new Date(log.timestamp).toLocaleTimeString()}
                  </td>
                  <td className="py-2 px-3 text-cyan-300 max-w-xs truncate">
                    {log.command}
                  </td>
                  <td className="py-2 px-3 text-slate-400">
                    {log.exitCode}
                  </td>
                  <td className="py-2 px-3 text-slate-300 max-w-sm truncate">
                    {log.output}
                  </td>
                  <td className="py-2 px-3">
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        log.status === 'SUCCESS'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : log.status === 'ROLLED_BACK'
                          ? 'bg-amber-950 text-amber-400 border border-amber-800'
                          : 'bg-rose-950 text-rose-400 border border-rose-800'
                      }`}
                    >
                      {log.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
