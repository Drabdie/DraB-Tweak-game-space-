import React, { useState, useRef, useEffect } from 'react';
import { DeviceTelemetry, OverlayConfig } from '../types';
import { Zap, X, Minimize2, Maximize2, Move, Flame, Cpu, Gauge } from 'lucide-react';

interface OverlayHUDProps {
  telemetry: DeviceTelemetry;
  config: OverlayConfig;
  onClose: () => void;
  onQuickBoost: () => void;
}

export const OverlayHUD: React.FC<OverlayHUDProps> = ({
  telemetry,
  config,
  onClose,
  onQuickBoost,
}) => {
  const [position, setPosition] = useState(config.position);
  const [isMinimized, setIsMinimized] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const dragRef = useRef<{ startX: number; startY: number; posX: number; posY: number }>({
    startX: 0,
    startY: 0,
    posX: position.x,
    posY: position.y,
  });

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      posX: position.x,
      posY: position.y,
    };
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      const dx = e.clientX - dragRef.current.startX;
      const dy = e.clientY - dragRef.current.startY;
      setPosition({
        x: Math.max(10, Math.min(window.innerWidth - 260, dragRef.current.posX + dx)),
        y: Math.max(10, Math.min(window.innerHeight - 180, dragRef.current.posY + dy)),
      });
    };

    const handleMouseUp = () => {
      setIsDragging(false);
    };

    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging]);

  const fpsColor =
    telemetry.display.currentFps >= 100
      ? 'text-emerald-400'
      : telemetry.display.currentFps >= 55
      ? 'text-cyan-400'
      : 'text-amber-400';

  const ramUsedGb = (telemetry.ram.usedMb / 1024).toFixed(1);
  const ramTotalGb = (telemetry.ram.totalMb / 1024).toFixed(1);

  if (isMinimized) {
    return (
      <div
        style={{ left: `${position.x}px`, top: `${position.y}px` }}
        className="fixed z-50 flex items-center gap-2 bg-slate-950/90 border border-emerald-500/40 backdrop-blur-md rounded-full px-3 py-1.5 shadow-2xl shadow-emerald-500/20 cursor-move select-none"
        onMouseDown={handleMouseDown}
      >
        <span className={`font-mono font-bold text-sm ${fpsColor}`}>
          {telemetry.display.currentFps} FPS
        </span>
        <span className="text-slate-500">|</span>
        <span className="text-xs text-slate-300 font-mono flex items-center gap-1">
          <Flame className="w-3 h-3 text-orange-400" />
          {telemetry.thermal.cpuTempC.toFixed(0)}°C
        </span>
        <button
          onClick={() => setIsMinimized(false)}
          className="ml-1 p-0.5 hover:text-emerald-400 text-slate-400"
          title="Развернуть оверлей"
        >
          <Maximize2 className="w-3 h-3" />
        </button>
      </div>
    );
  }

  return (
    <div
      style={{
        left: `${position.x}px`,
        top: `${position.y}px`,
        opacity: config.opacity,
      }}
      className="fixed z-50 w-64 bg-slate-950/95 border border-cyan-500/30 rounded-xl shadow-2xl shadow-cyan-950/50 backdrop-blur-md overflow-hidden select-none font-sans"
    >
      {/* HUD Header Bar */}
      <div
        className="flex items-center justify-between px-3 py-1.5 bg-gradient-to-r from-slate-900 to-slate-950 border-b border-slate-800 cursor-move"
        onMouseDown={handleMouseDown}
      >
        <div className="flex items-center gap-1.5 text-xs font-semibold tracking-wider text-cyan-400">
          <Move className="w-3 h-3 text-slate-400" />
          <span>GAMEBOOST HUD</span>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setIsMinimized(true)}
            className="p-1 text-slate-400 hover:text-white rounded"
            title="Свернуть"
          >
            <Minimize2 className="w-3 h-3" />
          </button>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-rose-400 rounded"
            title="Закрыть"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="p-3 space-y-2.5 text-xs">
        {/* Main FPS meter */}
        {config.showFps && (
          <div className="flex items-baseline justify-between bg-slate-900/80 rounded-lg px-2.5 py-1.5 border border-slate-800/80">
            <span className="text-slate-400 font-medium flex items-center gap-1">
              <Gauge className="w-3.5 h-3.5 text-cyan-400" />
              FPS (Choreographer)
            </span>
            <div className="text-right">
              <span className={`font-mono text-xl font-bold ${fpsColor}`}>
                {telemetry.display.currentFps}
              </span>
              <span className="text-[10px] text-slate-500 ml-1">/ {telemetry.display.refreshRateHz}Hz</span>
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 gap-2">
          {/* CPU usage */}
          {config.showCpu && (
            <div className="bg-slate-900/60 rounded-lg p-2 border border-slate-800">
              <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                <span className="flex items-center gap-1">
                  <Cpu className="w-3 h-3 text-cyan-400" /> CPU
                </span>
                <span className="font-mono text-white font-bold">{telemetry.totalCpuUsagePercent}%</span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div
                  className="bg-cyan-500 h-full rounded-full transition-all duration-300"
                  style={{ width: `${telemetry.totalCpuUsagePercent}%` }}
                />
              </div>
            </div>
          )}

          {/* RAM usage */}
          {config.showRam && (
            <div className="bg-slate-900/60 rounded-lg p-2 border border-slate-800">
              <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                <span>RAM</span>
                <span className="font-mono text-white font-bold">{ramUsedGb}G</span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div
                  className="bg-indigo-500 h-full rounded-full transition-all duration-300"
                  style={{
                    width: `${Math.round((telemetry.ram.usedMb / telemetry.ram.totalMb) * 100)}%`,
                  }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Thermal status */}
        {config.showTemp && (
          <div className="flex items-center justify-between px-2.5 py-1.5 bg-slate-900/60 rounded-lg border border-slate-800">
            <span className="text-slate-400 flex items-center gap-1">
              <Flame className="w-3.5 h-3.5 text-orange-400" />
              Температура
            </span>
            <div className="flex items-center gap-2 font-mono">
              <span className="text-orange-400 font-bold">{telemetry.thermal.cpuTempC.toFixed(1)}°C CPU</span>
              <span className="text-slate-500">·</span>
              <span className="text-slate-300">{telemetry.thermal.batteryTempC.toFixed(1)}°C Bat</span>
            </div>
          </div>
        )}

        {/* Quick boost button */}
        <button
          onClick={onQuickBoost}
          className="w-full py-1.5 mt-1 bg-gradient-to-r from-cyan-500 to-emerald-500 hover:from-cyan-400 hover:to-emerald-400 text-slate-950 font-bold rounded-lg flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all text-xs"
        >
          <Zap className="w-3.5 h-3.5 fill-current" />
          <span>Быстрый буст памяти</span>
        </button>
      </div>
    </div>
  );
};
