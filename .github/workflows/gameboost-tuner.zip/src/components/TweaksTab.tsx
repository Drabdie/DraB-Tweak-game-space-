import React, { useState } from 'react';
import { TweakItem, TweakMode, TweakCategory } from '../types';
import {
  Sliders,
  ShieldCheck,
  AlertTriangle,
  RotateCcw,
  Terminal,
  Search,
  CheckCircle2,
  ExternalLink,
  Code2,
  Lock,
  Layers,
} from 'lucide-react';

interface TweaksTabProps {
  tweaks: TweakItem[];
  currentMode: TweakMode;
  onToggleTweak: (tweakId: string) => void;
  onRestoreTweak: (tweakId: string) => void;
  onSwitchMode: (mode: TweakMode) => void;
}

export const TweaksTab: React.FC<TweaksTabProps> = ({
  tweaks,
  currentMode,
  onToggleTweak,
  onRestoreTweak,
  onSwitchMode,
}) => {
  const [filterMode, setFilterMode] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTweakForCmd, setSelectedTweakForCmd] = useState<TweakItem | null>(null);
  const [permissionErrorTweak, setPermissionErrorTweak] = useState<TweakItem | null>(null);

  const canApplyTweak = (tweak: TweakItem): boolean => {
    if (tweak.requiredMode === 'NON_ROOT') return true;
    if (tweak.requiredMode === 'SHIZUKU') return currentMode === 'SHIZUKU' || currentMode === 'ROOT';
    if (tweak.requiredMode === 'ROOT') return currentMode === 'ROOT';
    return false;
  };

  const handleToggleClick = (tweak: TweakItem) => {
    if (!canApplyTweak(tweak)) {
      setPermissionErrorTweak(tweak);
      return;
    }
    onToggleTweak(tweak.id);
  };

  const filteredTweaks = tweaks.filter((tweak) => {
    if (filterMode !== 'ALL' && tweak.requiredMode !== filterMode) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        tweak.name.toLowerCase().includes(q) ||
        tweak.description.toLowerCase().includes(q) ||
        tweak.category.toLowerCase().includes(q) ||
        (tweak.shellCommand && tweak.shellCommand.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const modeBadge = {
    NON_ROOT: {
      label: 'Non-Root',
      color: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    },
    SHIZUKU: {
      label: 'Shizuku / ADB',
      color: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30',
    },
    ROOT: {
      label: 'Root (su)',
      color: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
    },
  };

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2 font-['Chakra_Petch']">
              <Sliders className="w-6 h-6 text-cyan-400" />
              <span>СИСТЕМНЫЕ ТВЕРДЫЕ ТВЕКИ И ПАРАМЕТРЫ ЯДРА</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Честное переключение параметров с проверкой прав, снапшотом в Room DB и мгновенным откатом.
            </p>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            <span className="text-xs text-slate-400">Текущие права:</span>
            <span
              className={`text-xs px-2.5 py-1 rounded-lg border font-mono font-bold ${modeBadge[currentMode].color}`}
            >
              {currentMode}
            </span>
          </div>
        </div>

        {/* Filter Bar & Search */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2 border-t border-slate-800">
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none py-1">
            {[
              { id: 'ALL', label: 'Все твики' },
              { id: 'NON_ROOT', label: 'Non-Root' },
              { id: 'SHIZUKU', label: 'Shizuku (ADB)' },
              { id: 'ROOT', label: 'Root (su / sysfs)' },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setFilterMode(f.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                  filterMode === f.id
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                    : 'bg-slate-800/80 text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Search box */}
          <div className="relative min-w-[240px]">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Поиск по твикам или командам..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>
        </div>
      </div>

      {/* Tweaks Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredTweaks.map((tweak) => {
          const isAllowed = canApplyTweak(tweak);

          return (
            <div
              key={tweak.id}
              className={`bg-slate-900/90 border rounded-2xl p-5 shadow-lg transition-all space-y-3.5 relative overflow-hidden ${
                tweak.enabled
                  ? 'border-cyan-500/40 bg-gradient-to-b from-slate-900 via-slate-900 to-cyan-950/20'
                  : 'border-slate-800/90'
              }`}
            >
              {/* Header */}
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-white text-sm leading-snug">
                      {tweak.name}
                    </h3>
                    {tweak.isDangerous && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/30 font-mono">
                        Критичный
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] font-mono text-slate-500 block">
                    Категория: {tweak.category}
                  </span>
                </div>

                {/* Toggle switch */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleToggleClick(tweak)}
                    className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      tweak.enabled ? 'bg-cyan-500' : 'bg-slate-800'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                        tweak.enabled ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>

              {/* Description */}
              <p className="text-xs text-slate-300 leading-relaxed">
                {tweak.description}
              </p>

              {/* Value stats */}
              <div className="bg-slate-950/80 rounded-xl p-2.5 border border-slate-800/80 grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px] font-mono">
                <div>
                  <span className="text-slate-500 block text-[9px]">ТЕКУЩЕЕ</span>
                  <span
                    className={`font-bold ${
                      tweak.enabled ? 'text-cyan-400' : 'text-slate-300'
                    }`}
                  >
                    {tweak.currentValue}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[9px]">РЕКОМЕНДУЕМОЕ</span>
                  <span className="text-emerald-400 font-bold">
                    {tweak.recommendedValue}
                  </span>
                </div>
                {tweak.backedUpValue && (
                  <div className="col-span-2 sm:col-span-1">
                    <span className="text-slate-500 block text-[9px]">BACKUP В ROOM</span>
                    <span className="text-amber-400 font-bold">
                      {tweak.backedUpValue}
                    </span>
                  </div>
                )}
              </div>

              {/* Footer bar: permission badge & command inspect */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-800/60 text-xs">
                <div className="flex items-center gap-2">
                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded border font-bold ${
                      modeBadge[tweak.requiredMode].color
                    }`}
                  >
                    {modeBadge[tweak.requiredMode].label}
                  </span>

                  {!isAllowed && (
                    <span className="text-[10px] text-amber-400 flex items-center gap-1 font-mono">
                      <Lock className="w-3 h-3" />
                      Недостаточно прав
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  {tweak.backedUpValue && tweak.enabled && (
                    <button
                      onClick={() => onRestoreTweak(tweak.id)}
                      className="text-slate-400 hover:text-amber-400 text-[11px] flex items-center gap-1 font-medium transition-colors"
                      title="Откатить этот параметр к резервной копии"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Откатить</span>
                    </button>
                  )}

                  <button
                    onClick={() => setSelectedTweakForCmd(tweak)}
                    className="text-cyan-400 hover:text-cyan-300 text-[11px] flex items-center gap-1 font-medium transition-colors"
                  >
                    <Code2 className="w-3 h-3" />
                    <span>Команда</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Command Inspection Modal */}
      {selectedTweakForCmd && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-lg bg-slate-950 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-4 font-mono text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-cyan-400" />
                <h3 className="font-bold text-white text-sm">
                  {selectedTweakForCmd.name}
                </h3>
              </div>
              <button
                onClick={() => setSelectedTweakForCmd(null)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <span className="text-slate-400 text-[11px] block mb-1">
                  Метод выполнения:
                </span>
                <p className="bg-slate-900 p-2.5 rounded-lg border border-slate-800 text-slate-200">
                  {selectedTweakForCmd.commandExplanation}
                </p>
              </div>

              {selectedTweakForCmd.shellCommand && (
                <div>
                  <span className="text-slate-400 text-[11px] block mb-1">
                    Shell / su команда:
                  </span>
                  <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800 text-cyan-300 break-all select-all">
                    {selectedTweakForCmd.shellCommand}
                  </div>
                </div>
              )}

              {selectedTweakForCmd.verificationCommand && (
                <div>
                  <span className="text-slate-400 text-[11px] block mb-1">
                    Верификация значения (settings get / cat):
                  </span>
                  <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800 text-emerald-400 break-all select-all">
                    {selectedTweakForCmd.verificationCommand}
                  </div>
                </div>
              )}

              <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800 text-slate-400 space-y-1">
                <span className="text-white font-bold block">
                  Гарантия безопасности:
                </span>
                <p className="text-[11px] leading-relaxed">
                  При вызове ShellExecutor перед применением создаётся запись в Room DB (<code className="text-cyan-400">TweakBackupEntity</code>). Если выполнение возвращает ненулевой exit code или верификация не совпадает, немедленно запускается функция отката.
                </p>
              </div>
            </div>

            <div className="flex justify-end pt-2 border-t border-slate-800">
              <button
                onClick={() => setSelectedTweakForCmd(null)}
                className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-sans"
              >
                Закрыть
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Permission Blocked Explanatory Dialog */}
      {permissionErrorTweak && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-md bg-slate-950 border border-amber-500/40 rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-amber-400">
              <AlertTriangle className="w-6 h-6 flex-shrink-0" />
              <h3 className="font-bold text-white text-base">
                Требуются повышенные привилегии
              </h3>
            </div>

            <div className="text-xs text-slate-300 space-y-2 leading-relaxed">
              <p>
                Твик <strong>«{permissionErrorTweak.name}»</strong> требует режим{' '}
                <span className="text-amber-400 font-mono font-bold uppercase">
                  {permissionErrorTweak.requiredMode}
                </span>
                , тогда как текущий режим приложения —{' '}
                <span className="text-cyan-400 font-mono font-bold uppercase">
                  {currentMode}
                </span>
                .
              </p>
              <p className="text-slate-400">
                В честном приложении без root или Shizuku операционная система Android блокирует прямой доступ к{' '}
                <code className="text-cyan-400 font-mono">/sys/devices/system/cpu</code> или системным настройкам.
              </p>
            </div>

            <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between text-xs">
              <span className="text-slate-300">
                Переключить в симуляторе режим:
              </span>
              <button
                onClick={() => {
                  onSwitchMode(permissionErrorTweak.requiredMode);
                  setPermissionErrorTweak(null);
                }}
                className="px-3 py-1.5 bg-gradient-to-r from-cyan-500 to-emerald-500 text-slate-950 font-bold rounded-lg shadow-sm"
              >
                Включить {permissionErrorTweak.requiredMode}
              </button>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setPermissionErrorTweak(null)}
                className="px-4 py-1.5 rounded-lg text-slate-400 hover:text-white text-xs"
              >
                Понятно
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
