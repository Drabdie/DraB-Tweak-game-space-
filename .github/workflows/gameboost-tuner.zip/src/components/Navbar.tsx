import React from 'react';
import { TweakMode, DeviceTelemetry } from '../types';
import {
  Zap,
  Gauge,
  Gamepad2,
  Sliders,
  ShieldCheck,
  Terminal,
  FileCode,
  Info,
  Download,
  Flame,
  Layers,
} from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  onTabChange: (tab: string) => void;
  mode: TweakMode;
  onModeChange: (mode: TweakMode) => void;
  telemetry: DeviceTelemetry;
  overlayActive: boolean;
  onToggleOverlay: () => void;
  onOpenApkModal: () => void;
  onDownloadProjectZip: () => void;
  isExportingZip: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onTabChange,
  mode,
  onModeChange,
  telemetry,
  overlayActive,
  onToggleOverlay,
  onOpenApkModal,
  onDownloadProjectZip,
  isExportingZip,
}) => {
  const tabs = [
    { id: 'dashboard', label: 'Дашборд', icon: Gauge },
    { id: 'games', label: 'Игры & Профили', icon: Gamepad2 },
    { id: 'tweaks', label: 'Твики системы', icon: Sliders },
    { id: 'safety', label: 'Безопасность & Откат', icon: ShieldCheck },
    { id: 'shizuku', label: 'Shizuku / Root гид', icon: Terminal },
    { id: 'code', label: 'Код & Gradle', icon: FileCode },
    { id: 'about', label: 'О программе', icon: Info },
  ];

  const modeBadge = {
    NON_ROOT: {
      label: 'Non-Root (ADPF / Game Mode)',
      color: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
      dot: 'bg-emerald-400',
    },
    SHIZUKU: {
      label: 'Shizuku (ADB UID 2000)',
      color: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30',
      dot: 'bg-cyan-400',
    },
    ROOT: {
      label: 'Root (su / sysfs / proc)',
      color: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
      dot: 'bg-amber-400',
    },
  }[mode];

  return (
    <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800">
      {/* Top Bar: Brand, Hardware Live Stats & Primary Downloads */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5 flex flex-wrap items-center justify-between gap-3">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 via-indigo-600 to-emerald-500 flex items-center justify-center shadow-lg shadow-cyan-500/20 ring-1 ring-cyan-400/30">
            <Zap className="w-5 h-5 text-white fill-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-lg text-white tracking-wide font-['Chakra_Petch']">
                GAMEBOOST <span className="text-cyan-400">TUNER</span>
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-mono">
                v1.0.0
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">
              Android Game Turbo & Kernel / Shizuku Performance Engine
            </p>
          </div>
        </div>

        {/* Live Status Indicators & Mode Switcher */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          {/* Hardware Live Pulse */}
          <div className="hidden md:flex items-center gap-3 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono">
            <span className="flex items-center gap-1.5 text-slate-300">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-emerald-400 font-bold">{telemetry.display.currentFps}</span> FPS
            </span>
            <span className="text-slate-700">|</span>
            <span className="flex items-center gap-1 text-slate-300">
              <Flame className="w-3.5 h-3.5 text-orange-400" />
              <span>{telemetry.thermal.cpuTempC.toFixed(0)}°C</span>
            </span>
            <span className="text-slate-700">|</span>
            <span className="text-cyan-400">
              CPU {telemetry.totalCpuUsagePercent}%
            </span>
          </div>

          {/* Mode Switcher Selector */}
          <div className="flex items-center bg-slate-900 rounded-lg p-0.5 border border-slate-800">
            <button
              onClick={() => onModeChange('NON_ROOT')}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-all ${
                mode === 'NON_ROOT'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
              title="Режим без Root: стандартные API Android (Game Mode, ADPF, DND)"
            >
              Non-Root
            </button>
            <button
              onClick={() => onModeChange('SHIZUKU')}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-all ${
                mode === 'SHIZUKU'
                  ? 'bg-cyan-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
              title="Режим Shizuku: права ADB shell без рута через Wi-Fi"
            >
              Shizuku (ADB)
            </button>
            <button
              onClick={() => onModeChange('ROOT')}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-all ${
                mode === 'ROOT'
                  ? 'bg-amber-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
              title="Режим Root: прямой доступ к /sys/devices/system/cpu и ядру"
            >
              Root (su)
            </button>
          </div>

          {/* Overlay Toggle Button */}
          <button
            onClick={onToggleOverlay}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-all ${
              overlayActive
                ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 shadow-sm shadow-cyan-500/10'
                : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
            }`}
            title="Переключить плавающий FPS & Telemetry оверлей"
          >
            <Layers className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Оверлей HUD</span>
          </button>

          {/* Project ZIP Button */}
          <button
            onClick={onDownloadProjectZip}
            disabled={isExportingZip}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all disabled:opacity-50"
            title="Скачать весь исходный проект Android Studio (.zip)"
          >
            <FileCode className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden sm:inline">Проект (.zip)</span>
          </button>

          {/* Primary APK Download Action */}
          <button
            onClick={onOpenApkModal}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 shadow-md shadow-emerald-500/20 transition-all active:scale-95"
            title="Скачать готовый APK файл для установки на телефон"
          >
            <Download className="w-3.5 h-3.5 fill-current" />
            <span>Скачать APK</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-t border-slate-800/80">
        <nav className="flex space-x-1 sm:space-x-4 overflow-x-auto py-2 scrollbar-none">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = currentTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-slate-800/90 text-cyan-400 border border-cyan-500/30 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
