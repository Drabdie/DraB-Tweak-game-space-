import React, { useState } from 'react';
import { DeviceTelemetry, TweakMode, ProfileLevel } from '../types';
import {
  Zap,
  Cpu,
  Flame,
  Gauge,
  Activity,
  ShieldCheck,
  CheckCircle2,
  RefreshCw,
  Sliders,
  Server,
  AlertTriangle,
} from 'lucide-react';

interface DashboardTabProps {
  telemetry: DeviceTelemetry;
  mode: TweakMode;
  onTriggerBoost: () => void;
  isBoosting: boolean;
  activeProfile: ProfileLevel;
  onProfileSelect: (profile: ProfileLevel) => void;
  onNavigateToTab: (tab: string) => void;
}

export const DashboardTab: React.FC<DashboardTabProps> = ({
  telemetry,
  mode,
  onTriggerBoost,
  isBoosting,
  activeProfile,
  onProfileSelect,
  onNavigateToTab,
}) => {
  const [boostSuccessMsg, setBoostSuccessMsg] = useState<string | null>(null);

  const handleBoostClick = () => {
    onTriggerBoost();
    setBoostSuccessMsg('GameBoost: память оптимизирована, планировщик потоков сфокусирован!');
    setTimeout(() => setBoostSuccessMsg(null), 4000);
  };

  const headroomPercent = Math.round(telemetry.thermal.thermalHeadroom * 100);
  const isHeadroomCritical = telemetry.thermal.thermalHeadroom < 0.3;

  return (
    <div className="space-y-6">
      {/* Top Banner / Hero Card */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-900 via-slate-950 to-cyan-950/40 border border-slate-800 p-6 sm:p-8 shadow-xl">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -mb-10 -ml-10 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-xs font-mono text-cyan-300">
              <Activity className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              <span>ДВИЖОК ТЮНИНГА АКТИВЕН</span>
              <span className="text-slate-500">|</span>
              <span className="font-bold text-white uppercase">{mode} РЕЖИМ</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-['Chakra_Petch']">
              ФЛАГМАНСКИЙ GAME TURBO УСКОРИТЕЛЬ
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
              Мониторинг ядер в реальном времени через <code className="text-cyan-400 font-mono text-xs">/sys/devices/system/cpu</code>,
              ADPF Performance Hints, адаптивное управление частотами и защита от перегрева с авто-откатом.
            </p>

            {/* Profile Selector Buttons */}
            <div className="pt-2 flex flex-wrap items-center gap-2">
              <span className="text-xs text-slate-400 mr-1">Профиль:</span>
              {(['BALANCED', 'PERFORMANCE', 'EXTREME', 'CUSTOM'] as ProfileLevel[]).map((lvl) => (
                <button
                  key={lvl}
                  onClick={() => onProfileSelect(lvl)}
                  className={`px-3 py-1 text-xs font-medium rounded-lg transition-all ${
                    activeProfile === lvl
                      ? 'bg-gradient-to-r from-cyan-500 to-emerald-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {lvl}
                </button>
              ))}
            </div>
          </div>

          {/* Master Boost CTA */}
          <div className="flex flex-col sm:flex-row lg:flex-col items-center gap-3">
            <button
              onClick={handleBoostClick}
              disabled={isBoosting}
              className={`w-full sm:w-auto lg:w-56 py-3.5 px-6 rounded-xl font-extrabold text-sm sm:text-base flex items-center justify-center gap-3 shadow-xl transition-all active:scale-95 ${
                isBoosting
                  ? 'bg-slate-800 text-slate-400 cursor-not-allowed'
                  : 'bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-400 hover:from-cyan-400 hover:to-emerald-300 text-slate-950 shadow-cyan-500/25 ring-2 ring-cyan-400/40'
              }`}
            >
              {isBoosting ? (
                <>
                  <RefreshCw className="w-5 h-5 animate-spin" />
                  <span>УСКОРЕНИЕ...</span>
                </>
              ) : (
                <>
                  <Zap className="w-5 h-5 fill-current" />
                  <span>BOOST СИСТЕМЫ</span>
                </>
              )}
            </button>

            {boostSuccessMsg && (
              <div className="text-xs text-emerald-400 flex items-center gap-1.5 animate-fade-in font-medium">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>{boostSuccessMsg}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 4 Essential Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: FPS & Display */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5">
              <Gauge className="w-4 h-4 text-cyan-400" /> Частота кадров (FPS)
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 font-mono">
              Choreographer
            </span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold font-mono text-emerald-400">
              {telemetry.display.currentFps}
            </span>
            <span className="text-xs text-slate-400 font-mono">
              / {telemetry.display.refreshRateHz} Hz
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-2">
            Дропы кадров: <span className="text-emerald-400 font-mono">{telemetry.display.frameDropRate}%</span> (Стабильно)
          </p>
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-3 overflow-hidden">
            <div
              className="bg-emerald-500 h-full rounded-full transition-all duration-300"
              style={{
                width: `${Math.min(100, (telemetry.display.currentFps / telemetry.display.refreshRateHz) * 100)}%`,
              }}
            />
          </div>
        </div>

        {/* Metric 2: Thermal Headroom */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5">
              <Flame className="w-4 h-4 text-orange-400" /> Запас охлаждения
            </span>
            <span
              className={`text-[10px] px-2 py-0.5 rounded font-mono ${
                isHeadroomCritical
                  ? 'bg-rose-950 text-rose-400 border border-rose-800'
                  : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
              }`}
            >
              {isHeadroomCritical ? 'ТРОТТЛИНГ!' : 'БЕЗОПАСНО'}
            </span>
          </div>
          <div className="flex items-baseline gap-2">
            <span
              className={`text-3xl font-extrabold font-mono ${
                isHeadroomCritical ? 'text-rose-400' : 'text-cyan-400'
              }`}
            >
              {headroomPercent}%
            </span>
            <span className="text-xs text-slate-400 font-mono">headroom</span>
          </div>
          <p className="text-xs text-slate-400 mt-2">
            Battery: <span className="text-orange-300 font-mono">{telemetry.thermal.batteryTempC.toFixed(1)}°C</span> | CPU:{' '}
            <span className="text-orange-400 font-mono">{telemetry.thermal.cpuTempC.toFixed(1)}°C</span>
          </p>
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-3 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-300 ${
                isHeadroomCritical ? 'bg-rose-500' : 'bg-cyan-500'
              }`}
              style={{ width: `${headroomPercent}%` }}
            />
          </div>
        </div>

        {/* Metric 3: RAM Allocation */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5">
              <Server className="w-4 h-4 text-indigo-400" /> Память RAM
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-950 text-indigo-400 font-mono">
              ActivityManager
            </span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold font-mono text-indigo-400">
              {(telemetry.ram.usedMb / 1024).toFixed(1)}
            </span>
            <span className="text-xs text-slate-400 font-mono">
              / {(telemetry.ram.totalMb / 1024).toFixed(1)} GB
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-2">
            Свободно: <span className="text-slate-300 font-mono">{(telemetry.ram.freeMb / 1024).toFixed(1)} GB</span> | ZRAM Swap:{' '}
            <span className="text-slate-400 font-mono">{telemetry.ram.zramMb} MB</span>
          </p>
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-3 overflow-hidden">
            <div
              className="bg-indigo-500 h-full rounded-full transition-all duration-300"
              style={{
                width: `${Math.round((telemetry.ram.usedMb / telemetry.ram.totalMb) * 100)}%`,
              }}
            />
          </div>
        </div>

        {/* Metric 4: Total CPU Load */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5">
              <Cpu className="w-4 h-4 text-cyan-400" /> Загрузка CPU
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
              8 ядер
            </span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold font-mono text-cyan-400">
              {telemetry.totalCpuUsagePercent}%
            </span>
            <span className="text-xs text-slate-400 font-mono">активность</span>
          </div>
          <p className="text-xs text-slate-400 mt-2">
            Гувернер:{' '}
            <span className="text-emerald-400 font-mono uppercase font-bold">
              {telemetry.cpuCores[0]?.governor || 'schedutil'}
            </span>
          </p>
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-3 overflow-hidden">
            <div
              className="bg-cyan-500 h-full rounded-full transition-all duration-300"
              style={{ width: `${telemetry.totalCpuUsagePercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* 8-Core Detailed Cluster View */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-slate-800 pb-4">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2 font-['Chakra_Petch']">
              <Cpu className="w-5 h-5 text-cyan-400" />
              <span>ТЕЛЕМЕТРИЯ ЯДЕР CPU (sysfs cpufreq)</span>
            </h2>
            <p className="text-xs text-slate-400">
              Прямой опрос <code className="text-cyan-400 font-mono">/sys/devices/system/cpu/cpu[0-7]/cpufreq/scaling_cur_freq</code>
            </p>
          </div>
          <button
            onClick={() => onNavigateToTab('tweaks')}
            className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-medium"
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Настроить частоты и governor</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {telemetry.cpuCores.map((core) => {
            const clusterColor =
              core.cluster === 'PRIME'
                ? 'border-rose-500/40 bg-rose-950/20 text-rose-400'
                : core.cluster === 'MID'
                ? 'border-indigo-500/40 bg-indigo-950/20 text-indigo-400'
                : 'border-emerald-500/40 bg-emerald-950/20 text-emerald-400';

            const barColor =
              core.cluster === 'PRIME'
                ? 'bg-rose-500'
                : core.cluster === 'MID'
                ? 'bg-indigo-500'
                : 'bg-emerald-500';

            return (
              <div
                key={core.coreId}
                className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 space-y-2 hover:border-slate-700 transition-all"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-xs text-white">
                      Core #{core.coreId}
                    </span>
                    <span className={`text-[9px] px-1.5 py-0.5 rounded border font-mono font-bold ${clusterColor}`}>
                      {core.cluster}
                    </span>
                  </div>
                  <span className="text-xs font-mono text-slate-400">
                    {core.usagePercent}%
                  </span>
                </div>

                <div className="flex items-baseline justify-between font-mono">
                  <span className="text-base font-extrabold text-white">
                    {core.curFreqMhz} <span className="text-xs text-slate-400 font-normal">MHz</span>
                  </span>
                  <span className="text-[10px] text-slate-500">
                    max {core.maxFreqMhz} MHz
                  </span>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div
                    className={`${barColor} h-full rounded-full transition-all duration-300`}
                    style={{
                      width: `${Math.round((core.curFreqMhz / core.maxFreqMhz) * 100)}%`,
                    }}
                  />
                </div>

                <div className="flex items-center justify-between text-[10px] text-slate-500 pt-0.5">
                  <span>Gov: {core.governor}</span>
                  <span>min: {core.minFreqMhz} MHz</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Honest Mode Safety Notice */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-emerald-400 mt-0.5 flex-shrink-0" />
        <div className="text-xs text-slate-300 space-y-1">
          <p className="font-semibold text-white">
            Честный аудит системных разрешений:
          </p>
          <p className="text-slate-400 leading-relaxed">
            В текущем режиме <strong className="text-cyan-400 uppercase">{mode}</strong> приложение использует
            только разрешённые для него подсистемы. Если root не предоставлен, твики ядра блокируются с понятным
            объяснением вместо создания видимости работы (плацебо).
          </p>
        </div>
      </div>
    </div>
  );
};
