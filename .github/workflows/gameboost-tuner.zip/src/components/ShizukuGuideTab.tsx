import React, { useState } from 'react';
import { TweakMode } from '../types';
import {
  Terminal,
  Wifi,
  Shield,
  CheckCircle2,
  Copy,
  ExternalLink,
  Cpu,
  HelpCircle,
  Play,
  Layers,
} from 'lucide-react';

interface ShizukuGuideTabProps {
  currentMode: TweakMode;
  onSwitchMode: (mode: TweakMode) => void;
}

export const ShizukuGuideTab: React.FC<ShizukuGuideTabProps> = ({
  currentMode,
  onSwitchMode,
}) => {
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);
  const [shizukuPingResult, setShizukuPingResult] = useState<string | null>(null);
  const [rootCheckResult, setRootCheckResult] = useState<string | null>(null);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(text);
    setTimeout(() => setCopiedCmd(null), 2500);
  };

  const handlePingShizuku = () => {
    setShizukuPingResult('Проверка Shizuku IPC Binder...');
    setTimeout(() => {
      setShizukuPingResult('✅ Shizuku IPC активен! UID: 2000 (shell). Доступ к settings put и am предоставлен.');
      onSwitchMode('SHIZUKU');
    }, 1200);
  };

  const handleCheckRoot = () => {
    setRootCheckResult('Выполнение su -c id...');
    setTimeout(() => {
      setRootCheckResult('✅ Root получен! uid=0(root) gid=0(root). Доступ к /sys/devices/system/cpu/cpufreq открыт.');
      onSwitchMode('ROOT');
    }, 1200);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2 font-['Chakra_Petch']">
              <Terminal className="w-6 h-6 text-cyan-400" />
              <span>SHIZUKU & ROOT: ИНСТРУКЦИЯ И КОМАНДЫ ADB</span>
            </h2>
            <p className="text-xs text-slate-300 mt-1">
              Как получить привилегии уровня ADB UID 2000 без Root или полный доступ к ядру через KernelSU / Magisk.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePingShizuku}
              className="px-3.5 py-2 rounded-xl text-xs font-bold bg-cyan-600 hover:bg-cyan-500 text-white flex items-center gap-1.5 shadow-md shadow-cyan-900/30 transition-all"
            >
              <Wifi className="w-4 h-4" />
              <span>Тест Shizuku Binder</span>
            </button>
            <button
              onClick={handleCheckRoot}
              className="px-3.5 py-2 rounded-xl text-xs font-bold bg-amber-600 hover:bg-amber-500 text-white flex items-center gap-1.5 shadow-md shadow-amber-900/30 transition-all"
            >
              <Cpu className="w-4 h-4" />
              <span>Тест Root su</span>
            </button>
          </div>
        </div>

        {shizukuPingResult && (
          <div className="p-3 bg-cyan-950/80 border border-cyan-500/40 rounded-xl text-xs text-cyan-200 font-mono flex items-center gap-2">
            <span>{shizukuPingResult}</span>
          </div>
        )}

        {rootCheckResult && (
          <div className="p-3 bg-amber-950/80 border border-amber-500/40 rounded-xl text-xs text-amber-200 font-mono flex items-center gap-2">
            <span>{rootCheckResult}</span>
          </div>
        )}
      </div>

      {/* Permissions Matrix */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <h3 className="text-base font-bold text-white font-['Chakra_Petch']">
          СИСТЕМНЫЕ РАЗРЕШЕНИЯ ПРИЛОЖЕНИЯ
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {[
            {
              name: 'SYSTEM_ALERT_WINDOW',
              label: 'Плавающий оверлей поверх игр',
              status: 'Предоставлено',
              color: 'text-emerald-400 border-emerald-500/30 bg-emerald-950/20',
            },
            {
              name: 'PACKAGE_USAGE_STATS',
              label: 'Обнаружение активной игры',
              status: 'Предоставлено',
              color: 'text-emerald-400 border-emerald-500/30 bg-emerald-950/20',
            },
            {
              name: 'WRITE_SECURE_SETTINGS',
              label: 'Шкала анимаций и системные ключи',
              status: currentMode === 'NON_ROOT' ? 'Требует Shizuku / ADB' : 'Предоставлено',
              color:
                currentMode === 'NON_ROOT'
                  ? 'text-amber-400 border-amber-500/30 bg-amber-950/20'
                  : 'text-emerald-400 border-emerald-500/30 bg-emerald-950/20',
            },
            {
              name: 'ACCESSIBILITY_SERVICE',
              label: 'Служба авто-буста при запуске игры',
              status: 'Активно (Только чтение)',
              color: 'text-emerald-400 border-emerald-500/30 bg-emerald-950/20',
            },
            {
              name: 'FOREGROUND_SERVICE',
              label: 'Фоновый FPS HUD и сторож температуры',
              status: 'Предоставлено',
              color: 'text-emerald-400 border-emerald-500/30 bg-emerald-950/20',
            },
            {
              name: 'ROOT ACCESS (/system/bin/su)',
              label: 'Прямой доступ к sysfs cpufreq',
              status: currentMode === 'ROOT' ? 'UID 0 Доступен' : 'Не активен',
              color:
                currentMode === 'ROOT'
                  ? 'text-emerald-400 border-emerald-500/30 bg-emerald-950/20'
                  : 'text-slate-500 border-slate-800 bg-slate-950/40',
            },
          ].map((perm) => (
            <div
              key={perm.name}
              className={`p-3 rounded-xl border space-y-1 ${perm.color}`}
            >
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs font-bold text-white truncate max-w-[190px]">
                  {perm.name}
                </span>
                <span className="text-[10px] font-mono">{perm.status}</span>
              </div>
              <p className="text-[11px] text-slate-400">{perm.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Shizuku Wireless Setup 4-Step Walkthrough */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-5">
        <h3 className="text-base font-bold text-white flex items-center gap-2 font-['Chakra_Petch']">
          <Wifi className="w-5 h-5 text-cyan-400" />
          <span>БЕСПРОВОДНОЕ ПОДКЛЮЧЕНИЕ SHIZUKU (БЕЗ КОМПЬЮТЕРА, ANDROID 11+)</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-300">
          <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 space-y-2">
            <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 font-bold flex items-center justify-center text-xs">
              1
            </span>
            <h4 className="font-bold text-white text-sm">
              Включите Беспроводную отладку
            </h4>
            <p className="text-slate-400 leading-relaxed">
              Откройте <strong>Настройки &gt; Для разработчиков &gt; Отладка по беспроводной сети (Wireless Debugging)</strong>.
              Подключитесь к домашней Wi-Fi сети.
            </p>
          </div>

          <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 space-y-2">
            <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 font-bold flex items-center justify-center text-xs">
              2
            </span>
            <h4 className="font-bold text-white text-sm">
              Сопряжение (Pairing) в Shizuku
            </h4>
            <p className="text-slate-400 leading-relaxed">
              В Shizuku нажмите <strong>Сопряжение (Pairing)</strong>, затем в шторке введите 6-значный код, показанный в настройках беспроводной отладки.
            </p>
          </div>

          <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 space-y-2">
            <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 font-bold flex items-center justify-center text-xs">
              3
            </span>
            <h4 className="font-bold text-white text-sm">
              Запуск службы
            </h4>
            <p className="text-slate-400 leading-relaxed">
              Нажмите <strong>Запустить (Start)</strong> в Shizuku. Служба запустит локальный ADB-демон с UID 2000.
            </p>
          </div>

          <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 space-y-2">
            <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 font-bold flex items-center justify-center text-xs">
              4
            </span>
            <h4 className="font-bold text-white text-sm">
              Авто-авторизация GameBoost
            </h4>
            <p className="text-slate-400 leading-relaxed">
              Откройте GameBoost Tuner. Появится запрос разрешения Shizuku. Нажмите <strong>Всегда разрешать</strong>.
            </p>
          </div>
        </div>
      </div>

      {/* Copyable ADB Command Snippets */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <h3 className="text-base font-bold text-white font-['Chakra_Petch']">
          КОПИРУЕМЫЕ КОМАНДЫ ДЛЯ ПК ИЛИ TERMUX
        </h3>

        <div className="space-y-3 font-mono text-xs">
          {[
            {
              title: 'Установка APK на устройство через USB / Wi-Fi ADB:',
              cmd: 'adb install -r GameBoostTuner-v1.0.0-release.apk',
            },
            {
              title: 'Выдача разрешения WRITE_SECURE_SETTINGS через ПК/ADB:',
              cmd: 'adb shell pm grant com.gameboost.tuner android.permission.WRITE_SECURE_SETTINGS',
            },
            {
              title: 'Выдача разрешения PACKAGE_USAGE_STATS через ADB:',
              cmd: 'adb shell pm grant com.gameboost.tuner android.permission.PACKAGE_USAGE_STATS',
            },
            {
              title: 'Ручной запуск Shizuku через кабель USB:',
              cmd: 'adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh',
            },
            {
              title: 'Проверка прав root su на устройстве:',
              cmd: 'adb shell su -c "id"',
            },
          ].map((item, idx) => (
            <div key={idx} className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5">
              <span className="text-[11px] text-slate-400 font-sans block">
                {item.title}
              </span>
              <div className="flex items-center justify-between gap-2 bg-slate-900/90 p-2 rounded-lg border border-slate-800">
                <code className="text-cyan-300 break-all select-all">
                  {item.cmd}
                </code>
                <button
                  onClick={() => copyToClipboard(item.cmd)}
                  className="p-1.5 hover:text-cyan-400 text-slate-400 transition-colors flex-shrink-0"
                  title="Копировать"
                >
                  {copiedCmd === item.cmd ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
