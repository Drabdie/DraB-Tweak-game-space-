#!/bin/bash
set -e

BUILD_DIR="/tmp/apk_build"
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR/src/com/gameboost/tuner"
mkdir -p "$BUILD_DIR/res/values"
mkdir -p "$BUILD_DIR/res/drawable"
mkdir -p "$BUILD_DIR/bin"

# 1. Strings & Manifest
cat << 'EOF' > "$BUILD_DIR/res/values/strings.xml"
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">GameBoost Tuner</string>
</resources>
EOF

# 1x1 png icon
python3 -c "
import base64
png_data = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/5+hHgAHggJ/PchI7wAAAABJRU5ErkJggg==')
with open('$BUILD_DIR/res/drawable/ic_launcher.png', 'wb') as f:
    f.write(png_data)
"

cat << 'EOF' > "$BUILD_DIR/AndroidManifest.xml"
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.gameboost.tuner"
    android:versionCode="100"
    android:versionName="1.0.0">

    <uses-sdk android:minSdkVersion="26" android:targetSdkVersion="35" />

    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
    <uses-permission android:name="android.permission.PACKAGE_USAGE_STATS" />
    <uses-permission android:name="android.permission.WRITE_SECURE_SETTINGS" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

    <application
        android:label="@string/app_name"
        android:icon="@drawable/ic_launcher"
        android:allowBackup="true"
        android:supportsRtl="true"
        android:theme="@android:style/Theme.DeviceDefault.NoActionBar">

        <activity
            android:name="com.gameboost.tuner.MainActivity"
            android:exported="true"
            android:launchMode="singleTask">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
EOF

# 2. Main Activity (Java 17 target 8/11 for Android D8)
cat << 'EOF' > "$BUILD_DIR/src/com/gameboost/tuner/MainActivity.java"
package com.gameboost.tuner;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.graphics.Color;
import android.view.Gravity;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(Color.parseColor("#020617"));
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(48, 48, 48, 48);

        TextView title = new TextView(this);
        title.setText("⚡ GAMEBOOST TUNER");
        title.setTextSize(24f);
        title.setTextColor(Color.parseColor("#38bdf8"));
        title.setGravity(Gravity.CENTER);

        TextView subtitle = new TextView(this);
        subtitle.setText("Android Performance Engine & Game Turbo\nStatus: Engine Active (v1.0.0)");
        subtitle.setTextSize(14f);
        subtitle.setTextColor(Color.parseColor("#94a3b8"));
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 24, 0, 0);

        layout.addView(title);
        layout.addView(subtitle);

        setContentView(layout);
    }
}
EOF

echo "==> 1. Generating R.java and initial package with aapt..."
aapt package -f -m \
    -J "$BUILD_DIR/src" \
    -M "$BUILD_DIR/AndroidManifest.xml" \
    -S "$BUILD_DIR/res" \
    -I /tmp/android.jar

echo "==> 2. Compiling Java sources..."
javac -d "$BUILD_DIR/bin" \
    -cp "/tmp/android.jar" \
    -source 8 -target 8 \
    "$BUILD_DIR/src/com/gameboost/tuner/"*.java

echo "==> 3. Running D8 to generate classes.dex..."
java -cp /tmp/r8.jar com.android.tools.r8.D8 \
    --lib /tmp/android.jar \
    --min-api 26 \
    --output "$BUILD_DIR/bin" \
    $(find "$BUILD_DIR/bin" -name "*.class")

echo "==> 4. Packaging APK with aapt..."
aapt package -f \
    -M "$BUILD_DIR/AndroidManifest.xml" \
    -S "$BUILD_DIR/res" \
    -I /tmp/android.jar \
    -F "$BUILD_DIR/unaligned.apk"

# Add classes.dex into unaligned.apk
(cd "$BUILD_DIR/bin" && aapt add "$BUILD_DIR/unaligned.apk" classes.dex)

echo "==> 5. Running zipalign 4-byte alignment..."
zipalign -p -f 4 "$BUILD_DIR/unaligned.apk" "$BUILD_DIR/aligned.apk"

echo "==> 6. Generating release keystore and signing with apksigner (v1 + v2 + v3)..."
KEYSTORE="$BUILD_DIR/gameboost.keystore"
keytool -genkeypair -v \
    -keystore "$KEYSTORE" \
    -alias gameboost \
    -keyalg RSA \
    -keysize 2048 \
    -validity 10000 \
    -storepass android \
    -keypass android \
    -dname "CN=GameBoost, OU=Performance, O=Android, L=MountainView, S=CA, C=US"

apksigner sign \
    --ks "$KEYSTORE" \
    --ks-key-alias gameboost \
    --ks-pass pass:android \
    --key-pass pass:android \
    --v1-signing-enabled true \
    --v2-signing-enabled true \
    --out "$BUILD_DIR/GameBoostTuner-v1.0.0-release.apk" \
    "$BUILD_DIR/aligned.apk"

echo "==> 7. Verifying APK signature..."
apksigner verify --verbose "$BUILD_DIR/GameBoostTuner-v1.0.0-release.apk"

# Copy to public/
mkdir -p /app/applet/public
cp "$BUILD_DIR/GameBoostTuner-v1.0.0-release.apk" /app/applet/public/GameBoostTuner-v1.0.0-release.apk

echo "SUCCESS: Valid signed APK generated at /app/applet/public/GameBoostTuner-v1.0.0-release.apk"
ls -lh /app/applet/public/GameBoostTuner-v1.0.0-release.apk
