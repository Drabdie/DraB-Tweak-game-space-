import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';
import { ANDROID_PROJECT_FILES } from '../src/data/projectFiles';

async function main() {
  const publicDir = path.resolve('public');
  if (!fs.existsSync(publicDir)) {
    fs.mkdirSync(publicDir, { recursive: true });
  }

  // 1. Build Source Zip
  const zip = new JSZip();
  for (const file of ANDROID_PROJECT_FILES) {
    zip.file(`GameBoostTuner/${file.path}`, file.content);
  }

  zip.file(
    'GameBoostTuner/gradle/wrapper/gradle-wrapper.properties',
    `distributionBase=GRADLE_USER_HOME\ndistributionPath=wrapper/dists\ndistributionUrl=https\\://services.gradle.org/distributions/gradle-8.11.1-bin.zip\nnetworkTimeout=10000\nvalidateDistributionUrl=true\n`
  );

  zip.file('GameBoostTuner/gradlew', `#!/bin/sh\nexec gradle "$@"\n`);

  const zipBuffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });

  const zipPath = path.join(publicDir, 'GameBoostTuner-FullSource.zip');
  fs.writeFileSync(zipPath, zipBuffer);
  console.log(`Generated FullSource.zip at ${zipPath}, size: ${zipBuffer.length} bytes`);
}

main().catch(console.error);
